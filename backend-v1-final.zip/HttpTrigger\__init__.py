import azure.functions as func
import json
import os
import logging
from datetime import datetime

def main(req: func.HttpRequest) -> func.HttpResponse:
    """Main HTTP trigger function for V1 model."""
    logging.info('IG-Shop-Agent API request processed.')
    
    # Get the route and method
    route = req.route_params.get('route', '')
    method = req.method.upper()
    
    # CORS headers
    cors_headers = {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, PATCH, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization"
    }
    
    try:
        # Handle CORS preflight requests
        if method == "OPTIONS":
            return func.HttpResponse("", status_code=200, headers=cors_headers)
        
        # Root endpoint
        if not route or route == "/":
            return func.HttpResponse(
                json.dumps({
                    "message": "IG-Shop-Agent API",
                    "status": "running",
                    "version": "1.0.0-v1",
                    "timestamp": datetime.utcnow().isoformat(),
                    "endpoints": {
                        "health": "/api/health",
                        "auth": "/api/auth/login",
                        "catalog": "/api/catalog",
                        "webhook": "/api/webhook/instagram"
                    },
                    "environment": {
                        "openai_configured": bool(os.getenv("OPENAI_API_KEY")),
                        "meta_configured": bool(os.getenv("META_APP_ID")),
                        "database_configured": bool(os.getenv("DATABASE_URL"))
                    }
                }),
                status_code=200,
                headers=cors_headers
            )
        
        # Health check endpoint
        elif route == "health":
            return func.HttpResponse(
                json.dumps({
                    "status": "healthy",
                    "timestamp": datetime.utcnow().isoformat(),
                    "version": "1.0.0-v1",
                    "method": method,
                    "route": route
                }),
                status_code=200,
                headers=cors_headers
            )
        
        # Catalog endpoint
        elif route == "catalog":
            if method == "GET":
                catalog_data = {
                    "products": [
                        {
                            "id": "prod_1",
                            "name": "قميص أبيض",
                            "name_en": "White Shirt",
                            "price": 25.00,
                            "currency": "JOD",
                            "description": "قميص أبيض عالي الجودة",
                            "description_en": "High quality white shirt",
                            "image": "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400",
                            "in_stock": True,
                            "category": "clothing"
                        },
                        {
                            "id": "prod_2",
                            "name": "بنطال جينز",
                            "name_en": "Jeans Pants",
                            "price": 45.00,
                            "currency": "JOD",
                            "description": "بنطال جينز مريح",
                            "description_en": "Comfortable jeans pants",
                            "image": "https://images.unsplash.com/photo-1542272604-787c3835535d?w=400",
                            "in_stock": True,
                            "category": "clothing"
                        },
                        {
                            "id": "prod_3",
                            "name": "حذاء رياضي",
                            "name_en": "Sports Shoes",
                            "price": 65.00,
                            "currency": "JOD",
                            "description": "حذاء رياضي مريح",
                            "description_en": "Comfortable sports shoes",
                            "image": "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400",
                            "in_stock": True,
                            "category": "shoes"
                        }
                    ],
                    "total": 3,
                    "page": 1,
                    "per_page": 10
                }
                return func.HttpResponse(
                    json.dumps(catalog_data),
                    status_code=200,
                    headers=cors_headers
                )
            else:
                return func.HttpResponse("Method not allowed", status_code=405, headers=cors_headers)
        
        # Auth login endpoint
        elif route == "auth/login":
            if method == "POST":
                try:
                    body = req.get_json()
                    email = body.get("email", "") if body else ""
                    password = body.get("password", "") if body else ""
                    
                    if email and password:
                        return func.HttpResponse(
                            json.dumps({
                                "success": True,
                                "token": "mock_jwt_token_123",
                                "user": {
                                    "id": "user_123",
                                    "email": email,
                                    "name": "Test User",
                                    "business_name": "محل الموضة",
                                    "business_name_en": "Fashion Store"
                                }
                            }),
                            status_code=200,
                            headers=cors_headers
                        )
                    else:
                        return func.HttpResponse(
                            json.dumps({"error": "Email and password required"}),
                            status_code=400,
                            headers=cors_headers
                        )
                except:
                    return func.HttpResponse(
                        json.dumps({"error": "Invalid JSON"}),
                        status_code=400,
                        headers=cors_headers
                    )
            else:
                return func.HttpResponse("Method not allowed", status_code=405, headers=cors_headers)
        
        # Instagram webhook endpoints
        elif route == "webhook/instagram":
            if method == "GET":
                # Webhook verification
                hub_mode = req.params.get("hub.mode")
                hub_challenge = req.params.get("hub.challenge")
                hub_verify_token = req.params.get("hub.verify_token")
                
                verify_token = os.getenv("META_WEBHOOK_VERIFY_TOKEN", "ig_shop_webhook_verify_123")
                
                logging.info(f"Webhook verification: mode={hub_mode}, token_match={hub_verify_token == verify_token}")
                
                if hub_mode == "subscribe" and hub_verify_token == verify_token:
                    return func.HttpResponse(hub_challenge, status_code=200)
                else:
                    return func.HttpResponse("Forbidden", status_code=403)
            
            elif method == "POST":
                # Webhook handler
                try:
                    body = req.get_json()
                    logging.info(f"Instagram webhook received: {body}")
                    # For now, just return OK - can add AI processing later
                    return func.HttpResponse("OK", status_code=200)
                except:
                    return func.HttpResponse("Error", status_code=500)
        
        # Default response for unknown routes
        else:
            return func.HttpResponse(
                json.dumps({
                    "error": "Endpoint not found",
                    "requested_route": route,
                    "method": method,
                    "available_endpoints": [
                        "/api/health",
                        "/api/catalog",
                        "/api/auth/login",
                        "/api/webhook/instagram"
                    ]
                }),
                status_code=404,
                headers=cors_headers
            )
            
    except Exception as e:
        logging.error(f"Function error: {str(e)}")
        return func.HttpResponse(
            json.dumps({
                "error": "Internal server error",
                "message": str(e),
                "route": route,
                "method": method
            }),
            status_code=500,
            headers=cors_headers
        ) 