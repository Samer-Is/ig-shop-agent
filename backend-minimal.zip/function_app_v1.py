"""
Azure Functions V1 Programming Model - More stable and compatible
"""
import azure.functions as func
import logging
import json
import os
from datetime import datetime

def main(req: func.HttpRequest) -> func.HttpResponse:
    """Main HTTP trigger function for V1 model."""
    logging.info('Python HTTP trigger function processed a request.')
    
    # Get the route
    route = req.route_params.get('route', '')
    method = req.method
    
    try:
        if route == 'health' or not route:
            # Health check endpoint
            return func.HttpResponse(
                json.dumps({
                    "status": "healthy",
                    "timestamp": datetime.utcnow().isoformat(),
                    "version": "1.0.0-v1",
                    "method": method,
                    "route": route,
                    "environment": {
                        "openai_configured": bool(os.getenv("OPENAI_API_KEY")),
                        "meta_configured": bool(os.getenv("META_APP_ID")),
                        "database_configured": bool(os.getenv("DATABASE_URL"))
                    }
                }),
                status_code=200,
                headers={"Content-Type": "application/json"}
            )
        
        elif route == 'catalog':
            # Simple catalog endpoint
            catalog = {
                "products": [
                    {
                        "id": "prod_1",
                        "name": "قميص أبيض",
                        "name_en": "White Shirt", 
                        "price": 25.00,
                        "currency": "JOD"
                    }
                ],
                "total": 1
            }
            return func.HttpResponse(
                json.dumps(catalog),
                status_code=200,
                headers={"Content-Type": "application/json"}
            )
            
        elif route.startswith('auth/login'):
            # Simple auth endpoint  
            if method == "POST":
                try:
                    body = req.get_json()
                    email = body.get("email", "") if body else ""
                    password = body.get("password", "") if body else ""
                    
                    if email and password:
                        return func.HttpResponse(
                            json.dumps({
                                "success": True,
                                "token": "mock_jwt_token_123",
                                "user": {"id": "user_123", "email": email}
                            }),
                            status_code=200,
                            headers={"Content-Type": "application/json"}
                        )
                    else:
                        return func.HttpResponse(
                            json.dumps({"error": "Email and password required"}),
                            status_code=400,
                            headers={"Content-Type": "application/json"}
                        )
                except:
                    return func.HttpResponse(
                        json.dumps({"error": "Invalid JSON"}),
                        status_code=400,
                        headers={"Content-Type": "application/json"}
                    )
            else:
                return func.HttpResponse("Method not allowed", status_code=405)
        
        elif route.startswith('webhook/instagram'):
            # Instagram webhook
            if method == "GET":
                # Webhook verification
                hub_mode = req.params.get("hub.mode")
                hub_challenge = req.params.get("hub.challenge")
                hub_verify_token = req.params.get("hub.verify_token")
                
                verify_token = os.getenv("META_WEBHOOK_VERIFY_TOKEN", "ig_shop_webhook_verify_123")
                
                if hub_mode == "subscribe" and hub_verify_token == verify_token:
                    return func.HttpResponse(hub_challenge, status_code=200)
                else:
                    return func.HttpResponse("Forbidden", status_code=403)
            
            elif method == "POST":
                # Webhook handler
                try:
                    body = req.get_json()
                    logging.info(f"Instagram webhook: {body}")
                    return func.HttpResponse("OK", status_code=200)
                except:
                    return func.HttpResponse("Error", status_code=500)
        
        else:
            # Default API info
            return func.HttpResponse(
                json.dumps({
                    "message": "IG-Shop-Agent API V1",
                    "version": "1.0.0-v1",
                    "endpoints": {
                        "health": "/api/health",
                        "catalog": "/api/catalog", 
                        "auth": "/api/auth/login",
                        "webhook": "/api/webhook/instagram"
                    }
                }),
                status_code=200,
                headers={"Content-Type": "application/json"}
            )
            
    except Exception as e:
        logging.error(f"Function error: {e}")
        return func.HttpResponse(
            json.dumps({"error": "Internal server error", "message": str(e)}),
            status_code=500,
            headers={"Content-Type": "application/json"}
        ) 