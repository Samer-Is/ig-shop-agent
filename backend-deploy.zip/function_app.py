"""
Simplified Azure Functions application for IG-Shop-Agent API Backend.
This version uses minimal dependencies to ensure it runs properly.
"""
import azure.functions as func
import logging
import json
import os
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create Azure Functions app
app = func.FunctionApp()


@app.function_name(name="health")
@app.route(route="health", auth_level=func.AuthLevel.ANONYMOUS)
def health(req: func.HttpRequest) -> func.HttpResponse:
    return func.HttpResponse(
        json.dumps({
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "version": "1.0.0"
        }),
        status_code=200,
        headers={"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"}
    )


@app.function_name(name="root")
@app.route(route="", auth_level=func.AuthLevel.ANONYMOUS)
def root(req: func.HttpRequest) -> func.HttpResponse:
    return func.HttpResponse(
        json.dumps({
            "message": "IG-Shop-Agent API",
            "status": "running",
            "version": "1.0.0",
            "endpoints": {
                "health": "/api/health",
                "auth": "/api/auth/login",
                "catalog": "/api/catalog",
                "webhook": "/api/webhook/instagram"
            }
        }),
        status_code=200,
        headers={"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"}
    )


@app.function_name(name="auth_login")
@app.route(route="auth/login", auth_level=func.AuthLevel.ANONYMOUS, methods=["POST", "OPTIONS"])
def auth_login(req: func.HttpRequest) -> func.HttpResponse:
    # Handle CORS preflight
    if req.method == "OPTIONS":
        return func.HttpResponse(
            "",
            status_code=200,
            headers={
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            }
        )
    
    try:
        body = req.get_json()
        email = body.get("email", "") if body else ""
        password = body.get("password", "") if body else ""
        
        if email and password:
            # Mock successful login
            return func.HttpResponse(
                json.dumps({
                    "success": True,
                    "token": "mock_jwt_token_123",
                    "user": {
                        "id": "user_123",
                        "email": email,
                        "name": "Test User"
                    }
                }),
                status_code=200,
                headers={"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"}
            )
        else:
            return func.HttpResponse(
                json.dumps({"error": "Email and password required"}),
                status_code=400,
                headers={"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"}
            )
    except:
        return func.HttpResponse(
            json.dumps({"error": "Invalid request"}),
            status_code=400,
            headers={"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"}
        )


@app.function_name(name="catalog")
@app.route(route="catalog", auth_level=func.AuthLevel.ANONYMOUS, methods=["GET", "OPTIONS"])
def catalog(req: func.HttpRequest) -> func.HttpResponse:
    # Handle CORS preflight
    if req.method == "OPTIONS":
        return func.HttpResponse(
            "",
            status_code=200,
            headers={
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            }
        )
    
    # Mock catalog data
    catalog_data = {
        "products": [
            {
                "id": "prod_1",
                "name": "قميص أبيض",
                "name_en": "White Shirt",
                "price": 25.00,
                "currency": "JOD",
                "description": "قميص أبيض عالي الجودة",
                "description_en": "High quality white shirt",
                "image": "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400",
                "in_stock": True,
                "category": "clothing"
            },
            {
                "id": "prod_2",
                "name": "بنطال جينز",
                "name_en": "Jeans Pants", 
                "price": 45.00,
                "currency": "JOD",
                "description": "بنطال جينز مريح",
                "description_en": "Comfortable jeans pants",
                "image": "https://images.unsplash.com/photo-1542272604-787c3835535d?w=400",
                "in_stock": True,
                "category": "clothing"
            },
            {
                "id": "prod_3",
                "name": "حذاء رياضي",
                "name_en": "Sports Shoes",
                "price": 65.00,
                "currency": "JOD",
                "description": "حذاء رياضي مريح",
                "description_en": "Comfortable sports shoes",
                "image": "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400",
                "in_stock": True,
                "category": "shoes"
            }
        ],
        "total": 3,
        "page": 1,
        "per_page": 10
    }
    
    return func.HttpResponse(
        json.dumps(catalog_data),
        status_code=200,
        headers={"Content-Type": "application/json", "Access-Control-Allow-Origin": "*"}
    )


@app.function_name(name="instagram_webhook_verify")
@app.route(route="webhook/instagram", auth_level=func.AuthLevel.ANONYMOUS, methods=["GET"])
def instagram_webhook_verify(req: func.HttpRequest) -> func.HttpResponse:
    hub_mode = req.params.get("hub.mode")
    hub_challenge = req.params.get("hub.challenge")
    hub_verify_token = req.params.get("hub.verify_token")
    
    verify_token = os.getenv("META_WEBHOOK_VERIFY_TOKEN", "ig_shop_webhook_verify_123")
    
    if hub_mode == "subscribe" and hub_verify_token == verify_token:
        return func.HttpResponse(hub_challenge, status_code=200)
    else:
        return func.HttpResponse("Forbidden", status_code=403)


@app.function_name(name="instagram_webhook_post")
@app.route(route="webhook/instagram", auth_level=func.AuthLevel.ANONYMOUS, methods=["POST"])
def instagram_webhook_post(req: func.HttpRequest) -> func.HttpResponse:
    try:
        body = req.get_json()
        # Log webhook for now - can add AI processing later
        return func.HttpResponse("OK", status_code=200)
    except:
        return func.HttpResponse("Error", status_code=500) 