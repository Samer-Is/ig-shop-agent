"""
Complete IG Shop Agent - Instagram DM Automation with AI
Features: OAuth, AI Responses, Customer DB, Order Processing, Analytics
"""
import azure.functions as func
import logging
import json
import os
import re
import requests
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import base64

# Configure logging
logging.basicConfig(level=logging.INFO)

# Create the main Function App
app = func.FunctionApp()

# Configuration
INSTAGRAM_APP_ID = os.getenv("INSTAGRAM_APP_ID", "")
INSTAGRAM_APP_SECRET = os.getenv("INSTAGRAM_APP_SECRET", "")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")

# In-memory storage (in production, use Azure Cosmos DB or similar)
instagram_tokens = {}
customer_database = {}
message_history = []
order_database = {}
analytics_data = {
    "total_messages": 0,
    "total_orders": 0,
    "response_rate": 100,
    "conversion_rate": 0
}

# Product catalog
PRODUCT_CATALOG = [
    {
        "id": "prod_1",
        "name": "قميص أبيض",
        "name_en": "White Shirt",
        "price": 25.00,
        "currency": "JOD",
        "description": "قميص أبيض عالي الجودة من القطن الطبيعي",
        "description_en": "High quality white cotton shirt",
        "image": "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400",
        "in_stock": True,
        "quantity": 50
    },
    {
        "id": "prod_2", 
        "name": "بنطال جينز",
        "name_en": "Jeans Pants",
        "price": 45.00,
        "currency": "JOD",
        "description": "بنطال جينز مريح وأنيق للاستخدام اليومي",
        "description_en": "Comfortable and stylish jeans for daily wear",
        "image": "https://images.unsplash.com/photo-1542272604-787c3835535d?w=400",
        "in_stock": True,
        "quantity": 30
    },
    {
        "id": "prod_3",
        "name": "حذاء رياضي",
        "name_en": "Sports Shoes",
        "price": 60.00,
        "currency": "JOD",
        "description": "حذاء رياضي مريح للجري والتمارين",
        "description_en": "Comfortable sports shoes for running and exercise",
        "image": "https://images.unsplash.com/photo-1549298916-b41d501d3772?w=400",
        "in_stock": True,
        "quantity": 25
    }
]

class AIAgent:
    """AI Agent for processing customer messages and generating responses"""
    
    def __init__(self):
        self.intent_patterns = {
            "greeting": [
                r"مرحبا|أهلا|السلام عليكم|hi|hello|hey",
                r"صباح الخير|مساء الخير|good morning|good evening"
            ],
            "product_inquiry": [
                r"منتجات|أريد|أشتري|عندكم|متوفر|products|want|buy|available",
                r"كم سعر|السعر|price|cost|how much",
                r"معروض|كتالوج|catalog|items|merchandise"
            ],
            "order_request": [
                r"أطلب|أريد أطلب|order|place order|buy",
                r"شراء|purchase|اشتري"
            ],
            "size_inquiry": [
                r"مقاسات|الحجم|size|sizes|medium|large|small",
                r"مقاس|حجم"
            ],
            "delivery_inquiry": [
                r"توصيل|شحن|delivery|shipping|يوصل|arrives",
                r"متى يوصل|when arrive|delivery time"
            ],
            "price_inquiry": [
                r"كم سعر|السعر|الثمن|price|cost|how much|expensive|cheap",
                r"غالي|رخيص|مكلف"
            ]
        }
    
    def detect_intent(self, message: str) -> Optional[str]:
        """Detect customer intent from message"""
        message_lower = message.lower()
        
        for intent, patterns in self.intent_patterns.items():
            for pattern in patterns:
                if re.search(pattern, message_lower):
                    return intent
        
        return "general"
    
    def detect_language(self, message: str) -> str:
        """Detect if message is Arabic or English"""
        arabic_chars = re.findall(r'[\u0600-\u06FF]', message)
        return "ar" if len(arabic_chars) > len(message) * 0.3 else "en"
    
    def generate_response(self, message: str, customer_id: str) -> Dict:
        """Generate AI response based on customer message"""
        intent = self.detect_intent(message)
        language = self.detect_language(message)
        
        response_data = {
            "message": message,
            "intent": intent,
            "language": language,
            "response": "",
            "suggested_products": [],
            "next_action": None
        }
        
        if intent == "greeting":
            if language == "ar":
                response_data["response"] = "مرحباً بك! أنا مساعدك الشخصي في متجر الأزياء. كيف يمكنني مساعدتك اليوم؟ 😊"
            else:
                response_data["response"] = "Hello! I'm your personal fashion store assistant. How can I help you today? 😊"
                
        elif intent == "product_inquiry":
            if language == "ar":
                response_data["response"] = "لدينا مجموعة رائعة من المنتجات! إليك أحدث منتجاتنا:"
            else:
                response_data["response"] = "We have an amazing collection of products! Here are our latest items:"
            
            # Add available products
            available_products = [p for p in PRODUCT_CATALOG if p["in_stock"]]
            response_data["suggested_products"] = available_products[:3]
            
        elif intent == "price_inquiry":
            if language == "ar":
                response_data["response"] = "أسعارنا تنافسية جداً! إليك قائمة المنتجات مع الأسعار:"
            else:
                response_data["response"] = "Our prices are very competitive! Here's our product list with prices:"
            
            response_data["suggested_products"] = PRODUCT_CATALOG
            
        elif intent == "order_request":
            if language == "ar":
                response_data["response"] = "ممتاز! سأساعدك في الطلب. أي منتج تريد طلبه؟"
            else:
                response_data["response"] = "Excellent! I'll help you with your order. Which product would you like to order?"
            
            response_data["next_action"] = "collect_order_details"
            response_data["suggested_products"] = [p for p in PRODUCT_CATALOG if p["in_stock"]]
            
        elif intent == "delivery_inquiry":
            if language == "ar":
                response_data["response"] = "نوصل إلى جميع أنحاء الأردن خلال 1-3 أيام عمل. التوصيل مجاني للطلبات فوق 50 دينار! 🚚"
            else:
                response_data["response"] = "We deliver across Jordan within 1-3 business days. Free delivery for orders above 50 JOD! 🚚"
                
        elif intent == "size_inquiry":
            if language == "ar":
                response_data["response"] = "متوفر جميع المقاسات من S إلى XL. أخبرني أي منتج تريد معرفة مقاساته؟"
            else:
                response_data["response"] = "All sizes available from S to XL. Which product would you like to know sizes for?"
                
        else:  # general
            if language == "ar":
                response_data["response"] = "شكراً لتواصلك معنا! كيف يمكنني مساعدتك؟ يمكنك أن تسأل عن المنتجات أو الأسعار أو التوصيل."
            else:
                response_data["response"] = "Thank you for contacting us! How can I help you? You can ask about products, prices, or delivery."
        
        return response_data

# Initialize AI Agent
ai_agent = AIAgent()

# === HEALTH CHECK ===
@app.function_name(name="Health")
@app.route(route="health", auth_level=func.AuthLevel.ANONYMOUS)
def health(req: func.HttpRequest) -> func.HttpResponse:
    """Health check endpoint"""
    logging.info('Health endpoint accessed')
    
    response_data = {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "version": "2.0.0",
        "message": "IG-Shop-Agent API with AI is running",
        "features": {
            "ai_agent": True,
            "instagram_oauth": True,
            "customer_db": True,
            "order_processing": True,
            "analytics": True
        }
    }
    
    return func.HttpResponse(
        json.dumps(response_data),
        status_code=200,
        headers={
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
        }
    )

# === INSTAGRAM OAUTH ===
@app.function_name(name="InstagramConfig")
@app.route(route="instagram/config", auth_level=func.AuthLevel.ANONYMOUS)
def instagram_config(req: func.HttpRequest) -> func.HttpResponse:
    """Get Instagram app configuration"""
    logging.info('Instagram config requested')
    
    config = {
        "app_id": INSTAGRAM_APP_ID,
        "oauth_url": "https://api.instagram.com/oauth/authorize",
        "available": bool(INSTAGRAM_APP_ID and INSTAGRAM_APP_SECRET)
    }
    
    return func.HttpResponse(
        json.dumps(config),
        status_code=200,
        headers={
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
        }
    )

@app.function_name(name="InstagramOAuthCallback")
@app.route(route="instagram/oauth/callback", auth_level=func.AuthLevel.ANONYMOUS, methods=["POST", "OPTIONS"])
def instagram_oauth_callback(req: func.HttpRequest) -> func.HttpResponse:
    """Handle Instagram OAuth callback"""
    logging.info('Instagram OAuth callback')
    
    if req.method == "OPTIONS":
        return func.HttpResponse(
            "",
            status_code=200,
            headers={
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            }
        )
    
    try:
        req_body = req.get_json()
        code = req_body.get('code')
        state = req_body.get('state')
        redirect_uri = req_body.get('redirect_uri')
        
        if not code:
            raise ValueError("Authorization code not provided")
        
        # Exchange code for access token
        token_url = "https://api.instagram.com/oauth/access_token"
        token_data = {
            "client_id": INSTAGRAM_APP_ID,
            "client_secret": INSTAGRAM_APP_SECRET,
            "grant_type": "authorization_code",
            "redirect_uri": redirect_uri,
            "code": code
        }
        
        token_response = requests.post(token_url, data=token_data)
        token_result = token_response.json()
        
        if "access_token" not in token_result:
            raise ValueError(f"Token exchange failed: {token_result}")
        
        # Get user info
        user_info_url = f"https://graph.instagram.com/me?fields=id,username,account_type,media_count&access_token={token_result['access_token']}"
        user_response = requests.get(user_info_url)
        user_info = user_response.json()
        
        # Store token and user info
        instagram_tokens["access_token"] = token_result["access_token"]
        instagram_tokens["user_info"] = user_info
        instagram_tokens["connected_at"] = datetime.utcnow().isoformat()
        
        response_data = {
            "success": True,
            "access_token": token_result["access_token"],
            "page_info": {
                "name": user_info.get("username", "Instagram Page"),
                "id": user_info.get("id"),
                "account_type": user_info.get("account_type"),
                "media_count": user_info.get("media_count", 0),
                "followers_count": "N/A"  # Would need additional API calls
            }
        }
        
        logging.info(f"Instagram OAuth successful for user: {user_info.get('username')}")
        
        return func.HttpResponse(
            json.dumps(response_data),
            status_code=200,
            headers={
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            }
        )
        
    except Exception as e:
        logging.error(f"Instagram OAuth error: {str(e)}")
        return func.HttpResponse(
            json.dumps({"success": False, "error": str(e)}),
            status_code=400,
            headers={
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            }
        )

@app.function_name(name="InstagramStatus")
@app.route(route="instagram/status", auth_level=func.AuthLevel.ANONYMOUS)
def instagram_status(req: func.HttpRequest) -> func.HttpResponse:
    """Check Instagram connection status"""
    logging.info('Instagram status checked')
    
    connected = "access_token" in instagram_tokens
    
    response_data = {
        "connected": connected,
        "access_token": instagram_tokens.get("access_token") if connected else None,
        "page_info": instagram_tokens.get("user_info") if connected else None,
        "connected_at": instagram_tokens.get("connected_at") if connected else None
    }
    
    return func.HttpResponse(
        json.dumps(response_data),
        status_code=200,
        headers={
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
        }
    )

@app.function_name(name="InstagramDisconnect")
@app.route(route="instagram/disconnect", auth_level=func.AuthLevel.ANONYMOUS, methods=["POST", "OPTIONS"])
def instagram_disconnect(req: func.HttpRequest) -> func.HttpResponse:
    """Disconnect Instagram"""
    logging.info('Instagram disconnect requested')
    
    if req.method == "OPTIONS":
        return func.HttpResponse(
            "",
            status_code=200,
            headers={
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            }
        )
    
    # Clear stored tokens
    instagram_tokens.clear()
    
    return func.HttpResponse(
        json.dumps({"success": True, "message": "Instagram disconnected"}),
        status_code=200,
        headers={
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
        }
    )

# === AI AGENT ===
@app.function_name(name="AITestResponse")
@app.route(route="ai/test-response", auth_level=func.AuthLevel.ANONYMOUS, methods=["POST", "OPTIONS"])
def ai_test_response(req: func.HttpRequest) -> func.HttpResponse:
    """Test AI response generation"""
    logging.info('AI test response requested')
    
    if req.method == "OPTIONS":
        return func.HttpResponse(
            "",
            status_code=200,
            headers={
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            }
        )
    
    try:
        req_body = req.get_json()
        message = req_body.get('message', '')
        customer_id = req_body.get('customer_id', 'test_customer')
        
        if not message:
            raise ValueError("Message is required")
        
        # Generate AI response
        ai_response = ai_agent.generate_response(message, customer_id)
        
        response_data = {
            "ai_response": ai_response["response"],
            "detected_intent": ai_response["intent"],
            "detected_language": ai_response["language"],
            "suggested_products": ai_response["suggested_products"],
            "next_action": ai_response.get("next_action")
        }
        
        return func.HttpResponse(
            json.dumps(response_data),
            status_code=200,
            headers={
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            }
        )
        
    except Exception as e:
        logging.error(f"AI test response error: {str(e)}")
        return func.HttpResponse(
            json.dumps({"error": str(e)}),
            status_code=400,
            headers={
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            }
        )

# === PRODUCT CATALOG ===
@app.function_name(name="Catalog")
@app.route(route="catalog", auth_level=func.AuthLevel.ANONYMOUS, methods=["GET", "OPTIONS"])
def catalog(req: func.HttpRequest) -> func.HttpResponse:
    """Get product catalog"""
    logging.info('Catalog endpoint accessed')
    
    if req.method == "OPTIONS":
        return func.HttpResponse(
            "",
            status_code=200,
            headers={
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            }
        )
    
    # Filter by availability if requested
    show_available_only = req.params.get("available_only", "false").lower() == "true"
    
    products = PRODUCT_CATALOG
    if show_available_only:
        products = [p for p in products if p["in_stock"]]
    
    catalog_data = {
        "products": products,
        "total": len(products),
        "last_updated": datetime.utcnow().isoformat()
    }
    
    return func.HttpResponse(
        json.dumps(catalog_data),
        status_code=200,
        headers={
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
        }
    )

# === ANALYTICS ===
@app.function_name(name="Analytics")
@app.route(route="analytics", auth_level=func.AuthLevel.ANONYMOUS)
def analytics(req: func.HttpRequest) -> func.HttpResponse:
    """Get analytics data"""
    logging.info('Analytics endpoint accessed')
    
    # Calculate analytics from stored data
    total_customers = len(customer_database)
    total_messages = len(message_history)
    total_orders = len(order_database)
    
    # Calculate conversion rate
    conversion_rate = (total_orders / total_messages * 100) if total_messages > 0 else 0
    
    # Recent activity (last 24 hours)
    recent_cutoff = datetime.utcnow() - timedelta(hours=24)
    recent_messages = [
        msg for msg in message_history 
        if datetime.fromisoformat(msg.get("timestamp", "1970-01-01")) > recent_cutoff
    ]
    
    analytics_response = {
        "total_messages": total_messages,
        "total_orders": total_orders,
        "total_customers": total_customers,
        "response_rate": 100,  # Assuming AI always responds
        "conversion_rate": round(conversion_rate, 1),
        "recent_activity": {
            "messages_24h": len(recent_messages),
            "new_customers_24h": 0  # Would calculate from customer_database timestamps
        },
        "last_updated": datetime.utcnow().isoformat()
    }
    
    return func.HttpResponse(
        json.dumps(analytics_response),
        status_code=200,
        headers={
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
        }
    )

# === RECENT MESSAGES ===
@app.function_name(name="RecentMessages")
@app.route(route="messages/recent", auth_level=func.AuthLevel.ANONYMOUS)
def recent_messages(req: func.HttpRequest) -> func.HttpResponse:
    """Get recent messages"""
    logging.info('Recent messages requested')
    
    # Get latest messages (limit to 20)
    recent_msgs = sorted(
        message_history, 
        key=lambda x: x.get("timestamp", ""), 
        reverse=True
    )[:20]
    
    response_data = {
        "messages": recent_msgs,
        "total": len(message_history),
        "last_updated": datetime.utcnow().isoformat()
    }
    
    return func.HttpResponse(
        json.dumps(response_data),
        status_code=200,
        headers={
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
        }
    )

# === INSTAGRAM WEBHOOK ===
@app.function_name(name="InstagramWebhookVerify")
@app.route(route="webhook/instagram", auth_level=func.AuthLevel.ANONYMOUS, methods=["GET"])
def instagram_webhook_verify(req: func.HttpRequest) -> func.HttpResponse:
    """Webhook verification for Instagram/Meta"""
    logging.info('Instagram webhook verification requested')
    
    hub_mode = req.params.get("hub.mode")
    hub_challenge = req.params.get("hub.challenge") 
    hub_verify_token = req.params.get("hub.verify_token")
    
    expected_verify_token = os.getenv("META_WEBHOOK_VERIFY_TOKEN", "igshop_webhook_verify_2024")
    
    logging.info(f"Webhook verification - Mode: {hub_mode}, Token received: {hub_verify_token}")
    
    if hub_mode == "subscribe" and hub_verify_token == expected_verify_token:
        logging.info("Webhook verification successful")
        return func.HttpResponse(hub_challenge, status_code=200)
    else:
        logging.warning("Webhook verification failed")
        return func.HttpResponse("Verification failed", status_code=403)

@app.function_name(name="InstagramWebhookReceive")
@app.route(route="webhook/instagram", auth_level=func.AuthLevel.ANONYMOUS, methods=["POST"])
def instagram_webhook_receive(req: func.HttpRequest) -> func.HttpResponse:
    """Receive and process Instagram webhook messages"""
    logging.info('Instagram webhook message received')
    
    try:
        webhook_data = req.get_json()
        logging.info(f"Webhook data: {json.dumps(webhook_data, indent=2)}")
        
        if webhook_data.get("object") == "page":
            for entry in webhook_data.get("entry", []):
                for messaging in entry.get("messaging", []):
                    sender_id = messaging.get("sender", {}).get("id")
                    message_text = messaging.get("message", {}).get("text", "")
                    
                    if sender_id and message_text:
                        # Process the message with AI
                        process_customer_message(sender_id, message_text)
        
        return func.HttpResponse(
            json.dumps({"status": "received"}),
            status_code=200,
            headers={
                "Content-Type": "application/json"
            }
        )
        
    except Exception as e:
        logging.error(f"Webhook processing error: {str(e)}")
        return func.HttpResponse(
            json.dumps({"error": "Processing failed"}),
            status_code=500,
            headers={
                "Content-Type": "application/json"
            }
        )

def process_customer_message(customer_id: str, message: str):
    """Process customer message with AI and store in database"""
    try:
        # Generate AI response
        ai_response = ai_agent.generate_response(message, customer_id)
        
        # Store customer info
        if customer_id not in customer_database:
            customer_database[customer_id] = {
                "id": customer_id,
                "first_contact": datetime.utcnow().isoformat(),
                "total_messages": 0,
                "orders": [],
                "preferences": {}
            }
        
        customer_database[customer_id]["total_messages"] += 1
        customer_database[customer_id]["last_contact"] = datetime.utcnow().isoformat()
        
        # Store message
        message_record = {
            "id": len(message_history) + 1,
            "customer_id": customer_id,
            "customer_name": f"Customer {customer_id[-4:]}",
            "message": message,
            "ai_response": ai_response["response"],
            "intent": ai_response["intent"],
            "language": ai_response["language"],
            "timestamp": datetime.utcnow().isoformat(),
            "suggested_products": ai_response.get("suggested_products", [])
        }
        
        message_history.append(message_record)
        
        # Update analytics
        analytics_data["total_messages"] = len(message_history)
        
        # Send response back to Instagram (would require API call in real implementation)
        logging.info(f"AI Response for {customer_id}: {ai_response['response']}")
        
    except Exception as e:
        logging.error(f"Message processing error: {str(e)}")

# === ROOT ENDPOINT ===
@app.function_name(name="RootEndpoint")
@app.route(route="", auth_level=func.AuthLevel.ANONYMOUS)
def root(req: func.HttpRequest) -> func.HttpResponse:
    """Root API information"""
    logging.info('Root endpoint accessed')
    
    response_data = {
        "message": "IG-Shop-Agent API with AI",
        "status": "running",
        "version": "2.0.0",
        "features": {
            "ai_agent": True,
            "instagram_oauth": True,
            "customer_database": True,
            "order_processing": True,
            "analytics": True
        },
        "endpoints": {
            "health": "/api/health",
            "catalog": "/api/catalog",
            "instagram_config": "/api/instagram/config",
            "instagram_oauth": "/api/instagram/oauth/callback",
            "instagram_status": "/api/instagram/status",
            "ai_test": "/api/ai/test-response",
            "analytics": "/api/analytics",
            "recent_messages": "/api/messages/recent",
            "webhook": "/api/webhook/instagram"
        }
    }
    
    return func.HttpResponse(
        json.dumps(response_data),
        status_code=200,
        headers={
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
        }
    ) 