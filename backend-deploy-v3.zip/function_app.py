"""
Simplified Azure Functions application for IG-Shop-Agent API Backend.
This version uses minimal dependencies to ensure it runs properly.
"""
import azure.functions as func
import logging
import json
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO)

# Create the main Function App
app = func.FunctionApp()

@app.function_name(name="HttpTrigger")
@app.route(route="health", auth_level=func.AuthLevel.ANONYMOUS)
def health(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Health endpoint accessed')
    
    response_data = {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "version": "1.0.0",
        "message": "IG-Shop-Agent API is running"
    }
    
    return func.HttpResponse(
        json.dumps(response_data),
        status_code=200,
        headers={
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
        }
    )

@app.function_name(name="RootEndpoint")
@app.route(route="", auth_level=func.AuthLevel.ANONYMOUS)
def root(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Root endpoint accessed')
    
    response_data = {
        "message": "IG-Shop-Agent API",
        "status": "running",
        "version": "1.0.0",
        "endpoints": {
            "health": "/api/health",
            "auth": "/api/auth/login",
            "catalog": "/api/catalog"
        }
    }
    
    return func.HttpResponse(
        json.dumps(response_data),
        status_code=200,
        headers={
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
        }
    )

@app.function_name(name="AuthLogin")
@app.route(route="auth/login", auth_level=func.AuthLevel.ANONYMOUS, methods=["POST", "OPTIONS"])
def auth_login(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Auth login endpoint accessed')
    
    # Handle CORS preflight
    if req.method == "OPTIONS":
        return func.HttpResponse(
            "",
            status_code=200,
            headers={
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "POST, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            }
        )
    
    try:
        req_body = req.get_json()
        email = req_body.get('email') if req_body else ""
        password = req_body.get('password') if req_body else ""
        
        if email and password:
            response_data = {
                "success": True,
                "token": "mock_jwt_token_123",
                "user": {
                    "id": "user_123",
                    "email": email,
                    "name": "Test User"
                }
            }
            return func.HttpResponse(
                json.dumps(response_data),
                status_code=200,
                headers={
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*"
                }
            )
        else:
            return func.HttpResponse(
                json.dumps({"error": "Email and password required"}),
                status_code=400,
                headers={
                    "Content-Type": "application/json",
                    "Access-Control-Allow-Origin": "*"
                }
            )
    except Exception as e:
        logging.error(f"Auth error: {str(e)}")
        return func.HttpResponse(
            json.dumps({"error": "Invalid request"}),
            status_code=400,
            headers={
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            }
        )

@app.function_name(name="Catalog")
@app.route(route="catalog", auth_level=func.AuthLevel.ANONYMOUS, methods=["GET", "OPTIONS"])
def catalog(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Catalog endpoint accessed')
    
    # Handle CORS preflight
    if req.method == "OPTIONS":
        return func.HttpResponse(
            "",
            status_code=200,
            headers={
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Methods": "GET, OPTIONS",
                "Access-Control-Allow-Headers": "Content-Type"
            }
        )
    
    # Mock catalog data
    catalog_data = {
        "products": [
            {
                "id": "prod_1",
                "name": "قميص أبيض",
                "name_en": "White Shirt",
                "price": 25.00,
                "currency": "JOD",
                "description": "قميص أبيض عالي الجودة",
                "image": "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400",
                "in_stock": True
            },
            {
                "id": "prod_2", 
                "name": "بنطال جينز",
                "name_en": "Jeans Pants",
                "price": 45.00,
                "currency": "JOD",
                "description": "بنطال جينز مريح",
                "image": "https://images.unsplash.com/photo-1542272604-787c3835535d?w=400",
                "in_stock": True
            }
        ],
        "total": 2
    }
    
    return func.HttpResponse(
        json.dumps(catalog_data),
        status_code=200,
        headers={
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*"
        }
    ) 