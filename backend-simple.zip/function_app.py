"""
Simplified Azure Functions application for IG-Shop-Agent API Backend.
This version uses minimal dependencies to ensure it runs properly.
"""
import azure.functions as func
import logging
import json
import os
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create Azure Functions app
app = func.FunctionApp()


@app.function_name(name="health")
@app.route(route="health", auth_level=func.AuthLevel.ANONYMOUS)
def health_check(req: func.HttpRequest) -> func.HttpResponse:
    """Health check endpoint for the API."""
    try:
        return func.HttpResponse(
            json.dumps({
                "status": "healthy",
                "timestamp": datetime.utcnow().isoformat(),
                "version": "1.0.0",
                "platform": "Azure Functions",
                "python_version": os.sys.version,
                "environment": "production"
            }),
            status_code=200,
            headers={"Content-Type": "application/json"}
        )
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return func.HttpResponse(
            json.dumps({"status": "error", "message": str(e)}),
            status_code=500,
            headers={"Content-Type": "application/json"}
        )


@app.function_name(name="api_auth_login")
@app.route(route="api/auth/login", auth_level=func.AuthLevel.ANONYMOUS, methods=["POST"])
def auth_login(req: func.HttpRequest) -> func.HttpResponse:
    """Simple authentication endpoint."""
    try:
        # Get request body
        try:
            body = req.get_json()
            email = body.get("email", "")
            password = body.get("password", "")
        except:
            return func.HttpResponse(
                json.dumps({"error": "Invalid JSON body"}),
                status_code=400,
                headers={"Content-Type": "application/json"}
            )
        
        # Simple validation (replace with real auth later)
        if email and password:
            # Mock successful login
            return func.HttpResponse(
                json.dumps({
                    "success": True,
                    "token": "mock_jwt_token_123",
                    "user": {
                        "id": "user_123",
                        "email": email,
                        "name": "Test User"
                    }
                }),
                status_code=200,
                headers={"Content-Type": "application/json"}
            )
        else:
            return func.HttpResponse(
                json.dumps({"error": "Email and password required"}),
                status_code=400,
                headers={"Content-Type": "application/json"}
            )
            
    except Exception as e:
        logger.error(f"Auth login error: {e}")
        return func.HttpResponse(
            json.dumps({"error": "Internal server error"}),
            status_code=500,
            headers={"Content-Type": "application/json"}
        )


@app.function_name(name="api_catalog")
@app.route(route="api/catalog", auth_level=func.AuthLevel.ANONYMOUS, methods=["GET"])
def get_catalog(req: func.HttpRequest) -> func.HttpResponse:
    """Get product catalog."""
    try:
        # Mock catalog data
        catalog = {
            "products": [
                {
                    "id": "prod_1",
                    "name": "قميص أبيض",
                    "name_en": "White Shirt",
                    "price": 25.00,
                    "currency": "JOD",
                    "description": "قميص أبيض عالي الجودة",
                    "description_en": "High quality white shirt",
                    "image": "https://example.com/shirt.jpg",
                    "in_stock": True,
                    "category": "clothing"
                },
                {
                    "id": "prod_2", 
                    "name": "بنطال جينز",
                    "name_en": "Jeans Pants",
                    "price": 45.00,
                    "currency": "JOD",
                    "description": "بنطال جينز مريح",
                    "description_en": "Comfortable jeans pants",
                    "image": "https://example.com/jeans.jpg",
                    "in_stock": True,
                    "category": "clothing"
                }
            ],
            "total": 2,
            "page": 1,
            "per_page": 10
        }
        
        return func.HttpResponse(
            json.dumps(catalog),
            status_code=200,
            headers={"Content-Type": "application/json"}
        )
        
    except Exception as e:
        logger.error(f"Catalog error: {e}")
        return func.HttpResponse(
            json.dumps({"error": "Failed to fetch catalog"}),
            status_code=500,
            headers={"Content-Type": "application/json"}
        )


@app.function_name(name="instagram_webhook_get")
@app.route(route="webhook/instagram", auth_level=func.AuthLevel.ANONYMOUS, methods=["GET"])
def instagram_webhook_verify(req: func.HttpRequest) -> func.HttpResponse:
    """Instagram webhook verification endpoint."""
    try:
        # Webhook verification
        hub_mode = req.params.get("hub.mode")
        hub_challenge = req.params.get("hub.challenge") 
        hub_verify_token = req.params.get("hub.verify_token")
        
        # Verify token (get from environment variables)
        verify_token = os.getenv("META_WEBHOOK_VERIFY_TOKEN", "ig_shop_webhook_verify_123")
        
        logger.info(f"Webhook verification: mode={hub_mode}, token_match={hub_verify_token == verify_token}")
        
        if hub_mode == "subscribe" and hub_verify_token == verify_token:
            logger.info("Instagram webhook verified successfully")
            return func.HttpResponse(hub_challenge, status_code=200)
        else:
            logger.warning("Instagram webhook verification failed")
            return func.HttpResponse("Forbidden", status_code=403)
            
    except Exception as e:
        logger.error(f"Instagram webhook verification error: {e}")
        return func.HttpResponse("Internal Server Error", status_code=500)


@app.function_name(name="instagram_webhook_post")
@app.route(route="webhook/instagram", auth_level=func.AuthLevel.ANONYMOUS, methods=["POST"])
def instagram_webhook_handler(req: func.HttpRequest) -> func.HttpResponse:
    """Instagram webhook handler for processing incoming messages."""
    try:
        # Process incoming webhook
        try:
            body = req.get_json()
            logger.info(f"Received Instagram webhook: {body}")
            
            # Simple response for now
            if body and body.get("object") == "instagram":
                return func.HttpResponse("OK", status_code=200)
            else:
                return func.HttpResponse("Invalid payload", status_code=400)
            
        except Exception as e:
            logger.error(f"Error processing Instagram webhook: {e}")
            return func.HttpResponse("Error", status_code=500)
        
    except Exception as e:
        logger.error(f"Instagram webhook error: {e}")
        return func.HttpResponse("Internal Server Error", status_code=500)


@app.function_name(name="root")
@app.route(route="", auth_level=func.AuthLevel.ANONYMOUS, methods=["GET"])
def root_handler(req: func.HttpRequest) -> func.HttpResponse:
    """Root endpoint."""
    return func.HttpResponse(
        json.dumps({
            "message": "IG-Shop-Agent API is running",
            "version": "1.0.0-simple",
            "status": "healthy",
            "timestamp": datetime.utcnow().isoformat(),
            "endpoints": {
                "health": "/api/health",
                "auth_login": "/api/auth/login",
                "catalog": "/api/catalog", 
                "webhook": "/api/webhook/instagram"
            },
            "environment": {
                "openai_configured": bool(os.getenv("OPENAI_API_KEY")),
                "meta_configured": bool(os.getenv("META_APP_ID")),
                "database_configured": bool(os.getenv("DATABASE_URL"))
            }
        }),
        status_code=200,
        headers={"Content-Type": "application/json"}
    ) 