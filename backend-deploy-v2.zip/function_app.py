"""
Azure Functions application for IG-Shop-Agent API Backend.
Uses Azure Functions V2 programming model with FastAPI integration.
"""
import azure.functions as func
import logging
import json
import os
from datetime import datetime

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create Azure Functions app
app = func.FunctionApp()


@app.function_name(name="health")
@app.route(route="health", auth_level=func.AuthLevel.ANONYMOUS)
def health_check(req: func.HttpRequest) -> func.HttpResponse:
    """Health check endpoint for the API."""
    try:
        return func.HttpResponse(
            json.dumps({
                "status": "healthy",
                "timestamp": datetime.utcnow().isoformat(),
                "version": "1.0.0",
                "platform": "Azure Functions"
            }),
            status_code=200,
            headers={"Content-Type": "application/json"}
        )
    except Exception as e:
        logger.error(f"Health check failed: {e}")
        return func.HttpResponse(
            json.dumps({"status": "error", "message": str(e)}),
            status_code=500,
            headers={"Content-Type": "application/json"}
        )


@app.function_name(name="api_proxy")
@app.route(route="api/{*path}", auth_level=func.AuthLevel.ANONYMOUS, methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"])
def api_proxy(req: func.HttpRequest) -> func.HttpResponse:
    """
    Proxy all API requests to FastAPI app.
    This allows FastAPI to run on Azure Functions.
    """
    try:
        # Import FastAPI app here to avoid import issues
        try:
            from main import app as fastapi_app
            from fastapi.testclient import TestClient
        except ImportError as e:
            logger.error(f"Failed to import FastAPI app: {e}")
            return func.HttpResponse(
                json.dumps({"error": "FastAPI app not available"}),
                status_code=500,
                headers={"Content-Type": "application/json"}
            )
        
        # Create test client
        client = TestClient(fastapi_app)
        
        # Get path from route
        path = req.route_params.get("path", "")
        full_path = f"/{path}" if path else "/"
        
        # Add query string if present
        if req.url.query:
            full_path += f"?{req.url.query}"
        
        # Get request body
        try:
            body = req.get_body().decode('utf-8') if req.get_body() else None
        except:
            body = None
        
        # Convert headers
        headers = dict(req.headers)
        
        # Make request to FastAPI app
        try:
            if req.method == "GET":
                response = client.get(full_path, headers=headers)
            elif req.method == "POST":
                response = client.post(full_path, data=body, headers=headers)
            elif req.method == "PUT":
                response = client.put(full_path, data=body, headers=headers)
            elif req.method == "DELETE":
                response = client.delete(full_path, headers=headers)
            elif req.method == "PATCH":
                response = client.patch(full_path, data=body, headers=headers)
            elif req.method == "OPTIONS":
                response = client.options(full_path, headers=headers)
            else:
                return func.HttpResponse(
                    "Method not allowed",
                    status_code=405
                )
            
            # Return response
            return func.HttpResponse(
                response.content,
                status_code=response.status_code,
                headers=dict(response.headers)
            )
        except Exception as e:
            logger.error(f"FastAPI client error: {e}")
            return func.HttpResponse(
                json.dumps({"error": "FastAPI request failed", "message": str(e)}),
                status_code=500,
                headers={"Content-Type": "application/json"}
            )
        
    except Exception as e:
        logger.error(f"API proxy error: {e}")
        return func.HttpResponse(
            json.dumps({"error": "Internal server error", "message": str(e)}),
            status_code=500,
            headers={"Content-Type": "application/json"}
        )


@app.function_name(name="instagram_webhook_get")
@app.route(route="webhook/instagram", auth_level=func.AuthLevel.ANONYMOUS, methods=["GET"])
def instagram_webhook_verify(req: func.HttpRequest) -> func.HttpResponse:
    """Instagram webhook verification endpoint."""
    try:
        # Webhook verification
        hub_mode = req.params.get("hub.mode")
        hub_challenge = req.params.get("hub.challenge")
        hub_verify_token = req.params.get("hub.verify_token")
        
        # Verify token (get from environment variables)
        verify_token = os.getenv("META_WEBHOOK_VERIFY_TOKEN")
        
        if hub_mode == "subscribe" and hub_verify_token == verify_token:
            logger.info("Instagram webhook verified successfully")
            return func.HttpResponse(hub_challenge, status_code=200)
        else:
            logger.warning("Instagram webhook verification failed")
            return func.HttpResponse("Forbidden", status_code=403)
            
    except Exception as e:
        logger.error(f"Instagram webhook verification error: {e}")
        return func.HttpResponse("Internal Server Error", status_code=500)


@app.function_name(name="instagram_webhook_post")
@app.route(route="webhook/instagram", auth_level=func.AuthLevel.ANONYMOUS, methods=["POST"])
def instagram_webhook_handler(req: func.HttpRequest) -> func.HttpResponse:
    """Instagram webhook handler for processing incoming messages."""
    try:
        # Process incoming webhook
        try:
            body = req.get_json()
            logger.info(f"Received Instagram webhook: {body}")
            
            # For now, just return OK - we'll implement message processing later
            if body.get("object") == "instagram":
                for entry in body.get("entry", []):
                    for messaging in entry.get("messaging", []):
                        logger.info(f"Message: {messaging}")
                        # TODO: Process message with AI agent
            
            return func.HttpResponse("OK", status_code=200)
            
        except Exception as e:
            logger.error(f"Error processing Instagram webhook: {e}")
            return func.HttpResponse("Error", status_code=500)
        
    except Exception as e:
        logger.error(f"Instagram webhook error: {e}")
        return func.HttpResponse("Internal Server Error", status_code=500)


@app.function_name(name="root")
@app.route(route="", auth_level=func.AuthLevel.ANONYMOUS, methods=["GET"])
def root_handler(req: func.HttpRequest) -> func.HttpResponse:
    """Root endpoint."""
    return func.HttpResponse(
        json.dumps({
            "message": "IG-Shop-Agent API is running",
            "version": "1.0.0",
            "status": "healthy",
            "endpoints": {
                "health": "/health",
                "api": "/api/*",
                "webhook": "/webhook/instagram"
            }
        }),
        status_code=200,
        headers={"Content-Type": "application/json"}
    ) 